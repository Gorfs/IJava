class Section2 {

    public static String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // QUESTION 1 
    // Déclarez la fonction letterToInt ci-dessous
    

    // QUESTION 2  
    // Déclarez la fonction cesarLetter ci-dessous


    // QUESTION 3  
    // Déclarez la fonction cesar  ci-dessous

	
    // QUESTION 4
    // Déclarez la fonction deCesarLetter ci-dessous    


    // QUESTION 5
    // Déclarez la fonction deCesar ci-dessous    


    // QUESTION 6
    // Déchiffrez le message "DOHD MDFWD HVW" dans la fonction principale



    /* ********************************************************** */
    /* FONCTION PRINCIPALE                                        */
    /* ********************************************************** */
    

    public static void main (String []args) {
    // Ecrivez vos tests dans le corps de cette fonction
    }
    


    /* ********************************************************** */
    /* FONCTIONS AUXILIAIRES                                      */
    /* ********************************************************** */
     

    // caractère à une position donnée
    public static String charAtPos(String s, int i) {
	return String.valueOf(s.charAt(i));
    }

    // test d'égalité entre chaînes de caractères
    public static boolean stringEquals(String s, String t) {
	return s.equals(t);
    }
    

}
