public class CharCode {

    public static int charToCode(char c) {
        return (int) c;
    }

    public static char codeToChar(int code) {
        return (char) code;
    }

    /* Écrivez vos fonctions ici */

    public static void main(String[] args) {

        /* Écrivez vos tests ici */

    }
}
