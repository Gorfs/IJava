class Section1 {

    /* ********************************************************** */
    /* EXERCICE 1 : ENTIERS NON SIGNES                            */
    /* ********************************************************** */


    // QUESTION 1 
    // Déclarez la fonction isBinaryEncoding ci-dessous
    

    // QUESTION 2  
    // Déclarez la fonction powerTwo ci-dessous


    // QUESTION 3
    // Déclarez la fonction decode ci-dessous    


    // QUESTION 4
    // Déclarez la *procédure* encodeAndPrint ci-dessous    


    // QUESTION 5
    // Déclarez la fonction encode ci-dessous    


    // QUESTION 6
    // Ecrivez le test dans la fonction main




    /* ********************************************************** */
    /* EXERCICE 2 : INVERSE                              */
    /* ********************************************************** */


    // QUESTION 1 
    // Déclarez la fonction inverse ci-dessous
    

    // QUESTION 2  
    // Déclarez les fonctions encodeInv et decodeInv ci-dessous



    /* ********************************************************** */
    /* EXERCICE 3 : ENTIERS SIGNES                                */
    /* ********************************************************** */


    // QUESTION 1 
    // Déclarez la fonction isNegative ci-dessous
    

    // QUESTION 2  
    // Déclarez la fonction decodeNeg ci-dessous


    // QUESTION 3
    // Déclarez la fonction encodeNeg ci-dessous    


    // QUESTION 4
    // Déclarez la procédure testFinal ci-dessous    



    /* ********************************************************** */
    /* FONCTION PRINCIPALE                                        */
    /* ********************************************************** */
    

    public static void main (String []args) {
    // Ecrivez vos tests dans le corps de cette fonction
    }
    


    /* ********************************************************** */
    /* FONCTIONS AUXILIAIRES                                      */
    /* ********************************************************** */
     

    // caractère à une position donnée
    public static String charAtPos(String s, int i) {
	return String.valueOf(s.charAt(i));
    }

    // test d'égalité entre chaînes de caractères
    public static boolean stringEquals(String s, String t) {
	return s.equals(t);
    }
    

}
